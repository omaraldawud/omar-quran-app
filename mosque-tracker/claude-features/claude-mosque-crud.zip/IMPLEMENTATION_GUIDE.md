# Mosque Editing Implementation Guide
## Role-Based Access Control for Mosque Management

---

## 📦 What's Included

### Backend (1 file)
- `mosque_details.php` - GET/PUT endpoint with role-based authorization

### Frontend Components (3 files)
- `MosqueEditForm.jsx` - Edit form for mosque details
- `MosqueAdminSidebar.jsx` - Sidebar for mosque_admin users
- `MasjidCard-Updated.jsx` - Card with conditional edit button

### Updated Files (2 files)
- `App-WithMosqueEditing.jsx` - Adds mosque editing view
- `Dashboard-Updated.jsx` - Conditional sidebar rendering

### CSS Files (3 files)
- `mosque-edit-form.css`
- `mosque-admin-sidebar.css`
- `masjid-card-additions.css`

---

## 🚀 Installation Steps

### Step 1: Backend Setup

**Copy PHP file:**
```bash
cp mosque_details.php /path/to/your/api/
```

**Test the endpoint:**
```bash
# You'll need to be logged in with a valid session
curl http://localhost/api/mosque_details.php?id=1 \
  --cookie "PHPSESSID=your_session_id"
```

---

### Step 2: Frontend Components

**A. Copy new components to `/src/components/`:**
```
src/components/
├── MosqueEditForm.jsx              (NEW)
└── layout/
    └── MosqueAdminSidebar.jsx      (NEW)
```

**B. Update existing component:**
```
src/components/layout/
└── MasjidCard.jsx                  (REPLACE with MasjidCard-Updated.jsx)
```

---

### Step 3: Update Core Files

**IMPORTANT: Backup first!**

```bash
# Backup
cp src/App.jsx src/App.jsx.backup
cp src/pages/Dashboard.jsx src/pages/Dashboard.jsx.backup
```

**Replace with updated versions:**
```
src/
├── App.jsx                         (REPLACE with App-WithMosqueEditing.jsx)
└── pages/
    └── Dashboard.jsx               (REPLACE with Dashboard-Updated.jsx)
```

---

### Step 4: CSS Files

**Copy CSS to `/src/assets/css/`:**
```
src/assets/css/
├── mosque-edit-form.css            (NEW)
├── mosque-admin-sidebar.css        (NEW)
└── masjid-card-additions.css       (NEW - or merge into existing masjid-card.css)
```

**Import in your main CSS or component files:**
```javascript
// In MosqueEditForm.jsx
import "../assets/css/mosque-edit-form.css";

// In MosqueAdminSidebar.jsx
import "../../assets/css/mosque-admin-sidebar.css";
```

---

## 🔐 Authorization Rules Summary

| Role | Can View | Can Edit | Sidebar Shown |
|------|----------|----------|---------------|
| **system_admin** | All mosques | All mosques | None |
| **organization_admin** | Org's mosques | Org's mosques | OrganizationSidebar |
| **mosque_admin** | Own mosque | Own mosque | MosqueAdminSidebar |

---

## 🎯 How It Works

### For mosque_admin:

1. Logs in and sees Dashboard
2. **MosqueAdminSidebar** appears on right
3. Sidebar shows their mosque info
4. Clicks "Edit Mosque" button
5. `MosqueEditForm` opens
6. Makes changes and saves
7. Redirected back to Dashboard

### For organization_admin:

1. Logs in and sees Dashboard
2. **OrganizationSidebar** appears (existing)
3. Sees list of organization's mosques in grid
4. Each MasjidCard has "Edit Mosque" button
5. Clicks edit on any mosque in their org
6. `MosqueEditForm` opens
7. Makes changes and saves
8. Redirected back to Dashboard

### For system_admin:

1. Logs in and sees Dashboard
2. **NO SIDEBAR** (clean view)
3. Sees ALL mosques in grid
4. Each MasjidCard has "Edit Mosque" button
5. Can edit ANY mosque
6. `MosqueEditForm` opens
7. Makes changes and saves
8. Redirected back to Dashboard

---

## 🧪 Testing Checklist

### Test 1: mosque_admin User
- [ ] Login as mosque_admin
- [ ] See MosqueAdminSidebar on right
- [ ] Sidebar shows correct mosque info
- [ ] Click "Edit Mosque" in sidebar
- [ ] Form loads with mosque data
- [ ] Change some fields and save
- [ ] Redirected back to Dashboard
- [ ] Try to edit different mosque (should fail)

### Test 2: organization_admin User
- [ ] Login as organization_admin
- [ ] See OrganizationSidebar
- [ ] See only organization's mosques in grid
- [ ] Each mosque card has "Edit Mosque" button
- [ ] Click edit on a mosque
- [ ] Form loads correctly
- [ ] Save changes successfully
- [ ] Try to edit mosque from different org (should fail)

### Test 3: system_admin User
- [ ] Login as system_admin
- [ ] NO sidebar appears
- [ ] See ALL mosques in grid
- [ ] Each mosque card has "Edit Mosque" button
- [ ] Can edit any mosque
- [ ] Changes save successfully

### Test 4: Authorization
- [ ] mosque_admin CANNOT edit other mosques (403 error)
- [ ] organization_admin CANNOT edit mosques outside their org (403)
- [ ] Independent mosque (organization_id=NULL) can only be edited by system_admin or its mosque_admin

### Test 5: Edge Cases
- [ ] User with no associated_mosque_id (shows error)
- [ ] Mosque with all empty fields (still loads)
- [ ] Very long mosque name (UI doesn't break)
- [ ] Invalid mosque ID (shows error)
- [ ] Network error during save (shows error message)

---

## 🔍 Key Changes Explained

### App.jsx Changes

**Added:**
```javascript
const [selectedMosqueId, setSelectedMosqueId] = useState(null);

// Updated navigateTo to accept mosqueId
const navigateTo = (view, mosqueId = null) => {
  setCurrentView(view);
  if (mosqueId !== null) {
    setSelectedMosqueId(mosqueId);
  }
};

// New view for editing
{currentView === "edit-mosque" && (
  <MosqueEditForm
    mosqueId={selectedMosqueId}
    userRole={user.role}
    onNavigate={navigateTo}
  />
)}
```

### Dashboard.jsx Changes

**Added:**
```javascript
// Accept onNavigate prop
export default function Dashboard({ ..., onNavigate }) {

// Handler to navigate to edit view
const handleEditMosque = (mosqueId) => {
  onNavigate("edit-mosque", mosqueId);
};

// Conditional sidebar rendering
{userRole === "organization_admin" && <OrganizationSidebar .../>}
{userRole === "mosque_admin" && <MosqueAdminSidebar .../>}
{/* system_admin gets NO sidebar */}
```

### MasjidCard.jsx Changes

**Added:**
```javascript
// Receives new props
export default function MasjidCard({
  ...,
  onEditMosque,
  userRole,
  userOrganizationId,
  userAssociatedMosqueId,
}) {

// Permission check
const canEdit = () => {
  if (userRole === "system_admin") return true;
  if (userRole === "organization_admin") {
    return organization_id === userOrganizationId;
  }
  if (userRole === "mosque_admin") {
    return id === userAssociatedMosqueId;
  }
  return false;
};

// Conditional button
{showEditButton && (
  <button onClick={handleEditMosque}>✏️ Edit Mosque</button>
)}
```

---

## 🐛 Common Issues & Solutions

### Issue: "Not authenticated" error
**Solution:** Check that session is being sent with credentials:
```javascript
fetch(url, { credentials: "include" })
```

### Issue: mosque_admin can't see edit button
**Solution:** Verify user object has `associated_mosque_id` field

### Issue: Edit form shows wrong mosque
**Solution:** Check that `selectedMosqueId` is being set correctly in `navigateTo`

### Issue: 403 Forbidden when editing
**Solution:** Check backend authorization logic matches user's role and mosque ownership

### Issue: Sidebar not showing
**Solution:** Verify role checks in Dashboard.jsx:
- `organization_admin` needs `organizationId`
- `mosque_admin` needs `associatedMosqueId`

### Issue: Changes not saving
**Solution:** 
1. Check network tab for errors
2. Verify PUT request is formatted correctly
3. Check backend validation (mosque name required)

---

## 📊 Database Requirements

Your users table must have:
```sql
users
├── id
├── user_name
├── user_email
├── role (system_admin, organization_admin, mosque_admin)
├── organization_id (nullable)
└── associated_mosque_id (nullable - for mosque_admin)
```

Your mosques table must have:
```sql
mosques
├── id
├── name
├── street, city, state, zip
├── contact_name, contact_email, contact_phone
├── website, facebook, whatsapp
└── organization_id (nullable - independent mosques)
```

---

## 🔒 Security Reminders

1. **Backend is source of truth** - All authorization happens in PHP
2. **Frontend hides UI** - But backend enforces permissions
3. **Session validation** - Every request checks session
4. **SQL injection protection** - Use parameterized queries
5. **Input validation** - Validate on both frontend and backend

---

## 📝 Next Steps (Future Enhancements)

After this is working, consider:
- [ ] Add audit logging (who edited what, when)
- [ ] Add image upload for mosque photos
- [ ] Add more fields (prayer times, services, etc.)
- [ ] Add mosque approval workflow
- [ ] Add bulk edit for organization_admin
- [ ] Add mosque search in OrganizationSidebar

---

## ✅ Final Verification

Before deploying:
1. All three roles tested thoroughly
2. Authorization works on backend
3. No console errors in browser
4. Mobile responsive layout works
5. Form validation prevents bad data
6. Success/error messages display properly
7. Navigation flows work smoothly

---

## 🎉 You're Done!

Your mosque editing system is now fully integrated with role-based access control!

Users can:
- ✅ Edit mosques based on their role
- ✅ See appropriate UI for their permissions
- ✅ Have changes validated and saved
- ✅ Navigate smoothly between views

The system enforces:
- ✅ Least-privilege access
- ✅ Backend authorization on every request
- ✅ Clean separation between roles
- ✅ Proper error handling

---

For questions or issues, review the MOSQUE_EDITING_PLAN.md file for detailed architecture decisions.
