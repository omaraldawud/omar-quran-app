# Mosque Editing Implementation Plan - Role-Based Access Control

## 🎯 Overview
Implement mosque editing with strict role-based permissions:
- **mosque_admin**: Edit only their mosque
- **organization_admin**: Edit mosques linked to their organization  
- **system_admin**: Edit any mosque

---

## 🗄️ Backend Plan

### Database Schema (Assumed)
```sql
-- mosques table
id, name, street, city, state, zip
contact_name, contact_email, contact_phone
website, facebook, whatsapp
organization_id (nullable - mosque may be independent)

-- users table  
id, user_name, user_email, role
organization_id (nullable)
associated_mosque_id (nullable - for mosque_admin)
```

### API Endpoints

#### 1. GET `/api/mosque_details.php?id={mosque_id}`
**Purpose**: Fetch single mosque details for editing
**Authorization**:
- `system_admin`: ANY mosque
- `organization_admin`: Mosques where `mosque.organization_id = user.organization_id`
- `mosque_admin`: Only where `mosque.id = user.associated_mosque_id`

**Response**:
```json
{
  "id": 1,
  "name": "Islamic Center of Example",
  "street": "123 Main St",
  "city": "Chicago",
  "state": "IL",
  "zip": "60601",
  "contact_name": "John Doe",
  "contact_email": "contact@example.com",
  "contact_phone": "555-1234",
  "website": "https://example.com",
  "facebook": "https://facebook.com/example",
  "whatsapp": "https://wa.me/1234567890",
  "organization_id": 1
}
```

#### 2. PUT `/api/mosque_details.php`
**Purpose**: Update mosque information
**Authorization**: Same as GET above
**Request Body**:
```json
{
  "id": 1,
  "name": "Updated Name",
  "street": "456 Oak Ave",
  // ... all editable fields
}
```

**Response**:
```json
{
  "success": true,
  "message": "Mosque updated successfully",
  "mosque": { /* updated mosque object */ }
}
```

#### 3. GET `/api/mosques.php` (MODIFY EXISTING)
**Current**: Returns all mosques
**Change**: Filter by role
- `system_admin`: All mosques
- `organization_admin`: Where `organization_id = user.organization_id`
- `mosque_admin`: Where `id = user.associated_mosque_id`

### Authorization Rules

```php
// Pseudo-code for authorization check
function canEditMosque($user, $mosqueId) {
    if ($user['role'] === 'system_admin') {
        return true;
    }
    
    $mosque = getMosqueById($mosqueId);
    
    if ($user['role'] === 'organization_admin') {
        return $mosque['organization_id'] === $user['organization_id'];
    }
    
    if ($user['role'] === 'mosque_admin') {
        return $mosque['id'] === $user['associated_mosque_id'];
    }
    
    return false;
}
```

---

## 🎨 Frontend Plan

### Component Structure

```
components/
├── MosqueEditForm.jsx         (NEW - edit mosque details)
├── MosqueAdminSidebar.jsx     (NEW - for mosque_admin)
└── layout/
    ├── OrganizationSidebar.jsx (MODIFY - add edit link for org_admin)
    └── MasjidCard.jsx          (MODIFY - conditional edit button)
```

### Routing Changes in App.jsx

```javascript
// Add new view state
const [currentView, setCurrentView] = useState("dashboard"); 
// Possible values: "dashboard", "profile", "admin", "edit-mosque"

// Add mosque editing view
{currentView === "edit-mosque" && (
  <MosqueEditForm 
    mosqueId={selectedMosqueId}
    userRole={user.role}
    onNavigate={navigateTo}
  />
)}
```

### Sidebar Behavior by Role

#### mosque_admin → MosqueAdminSidebar
```jsx
<MosqueAdminSidebar 
  mosqueId={user.associated_mosque_id}
  onEditMosque={() => navigateTo("edit-mosque")}
/>
```

**Displays**:
- Mosque name, logo, contact info
- Mission/vision
- Social links
- **"Edit Mosque" button** (navigates to edit form)

#### organization_admin → OrganizationSidebar (existing)
**Modify to add**:
- List of linked mosques
- Each mosque has "Edit" button
- Clicking edit loads MosqueEditForm

#### system_admin → NO SIDEBAR
- Dashboard shows all mosques in grid
- Each MasjidCard has "Edit" button
- Separate admin panel for org management

---

## 🔐 RBAC Enforcement

### Frontend Guards

```javascript
// In MosqueEditForm.jsx
useEffect(() => {
  const canEdit = checkEditPermission(user, mosqueId);
  if (!canEdit) {
    alert("You don't have permission to edit this mosque");
    onNavigate("dashboard");
  }
}, [mosqueId, user]);

function checkEditPermission(user, mosqueId) {
  if (user.role === 'system_admin') return true;
  if (user.role === 'mosque_admin') {
    return mosqueId === user.associated_mosque_id;
  }
  // For org_admin, need to check if mosque belongs to their org
  // This will be verified on backend
  return user.role === 'organization_admin';
}
```

### Backend Guards (in PHP)

```php
// In mosque_details.php
session_start();
$user = $_SESSION['user'];
$mosqueId = $_GET['id'] ?? $_POST['id'];

// Get mosque
$mosque = getMosque($mosqueId);

// Authorization check
if ($user['role'] === 'system_admin') {
    // allowed
} elseif ($user['role'] === 'organization_admin') {
    if ($mosque['organization_id'] !== $user['organization_id']) {
        http_response_code(403);
        echo json_encode(['error' => 'Access denied']);
        exit;
    }
} elseif ($user['role'] === 'mosque_admin') {
    if ($mosque['id'] !== $user['associated_mosque_id']) {
        http_response_code(403);
        echo json_encode(['error' => 'Access denied']);
        exit;
    }
} else {
    http_response_code(403);
    echo json_encode(['error' => 'Invalid role']);
    exit;
}
```

---

## 📊 Data Flow

### Loading Mosque for Editing

```
1. User clicks "Edit Mosque" button
   ↓
2. App.jsx: setCurrentView("edit-mosque"), setSelectedMosqueId(id)
   ↓
3. MosqueEditForm renders
   ↓
4. useEffect: fetch(`/api/mosque_details.php?id=${mosqueId}`)
   ↓
5. Backend: Check authorization → return data or 403
   ↓
6. Frontend: Populate form fields
   ↓
7. User edits and saves
   ↓
8. PUT /api/mosque_details.php
   ↓
9. Backend: Check authorization → update or 403
   ↓
10. Frontend: Show success → navigate back
```

### Sidebar Conditional Rendering

```javascript
// In App.jsx - Dashboard view
{currentView === "dashboard" && (
  <>
    <Dashboard {...props} />
    
    {/* Conditional sidebar based on role */}
    {user.role === 'mosque_admin' && (
      <MosqueAdminSidebar 
        mosqueId={user.associated_mosque_id}
        onNavigate={navigateTo}
      />
    )}
    
    {user.role === 'organization_admin' && (
      <OrganizationSidebar 
        organizationId={user.organization_id}
        onNavigate={navigateTo}
      />
    )}
    
    {/* system_admin has NO sidebar */}
  </>
)}
```

---

## 🧪 Edge Cases

### 1. Mosque with no organization
**Scenario**: Independent mosque (organization_id = NULL)
**Handling**:
- Only `mosque_admin` (for that mosque) or `system_admin` can edit
- `organization_admin` from any org CANNOT edit
- Backend must check `organization_id IS NOT NULL` for org_admin access

### 2. Organization with many mosques
**Scenario**: Organization has 50 mosques
**Handling**:
- OrganizationSidebar shows paginated or scrollable list
- Each mosque has "Edit" button
- Clicking edit loads that specific mosque in edit form

### 3. Mosque admin attempting org access
**Scenario**: `mosque_admin` tries to navigate to organization profile
**Handling**:
- Frontend: Hide "Organization Profile" nav button for mosque_admin
- Backend: API returns 403 if mosque_admin tries to access org endpoints
- Redirect to dashboard if they somehow reach the page

### 4. User with no associated_mosque_id
**Scenario**: `mosque_admin` role but no mosque assigned
**Handling**:
- Show error: "No mosque assigned to your account"
- Contact admin message
- Disable all mosque features

### 5. Concurrent edits
**Scenario**: Two admins edit same mosque simultaneously
**Handling**:
- Simple: Last-write-wins (acceptable for MVP)
- Advanced: Add `updated_at` timestamp, detect conflicts

---

## 🎯 Implementation Checklist

### Backend
- [ ] Create `mosque_details.php` (GET/PUT)
- [ ] Add authorization helper function
- [ ] Modify `mosques.php` to filter by role
- [ ] Add session checks to all endpoints
- [ ] Test authorization for each role

### Frontend
- [ ] Create `MosqueEditForm.jsx`
- [ ] Create `MosqueAdminSidebar.jsx`
- [ ] Modify `OrganizationSidebar.jsx` (add mosque list + edit)
- [ ] Modify `App.jsx` (add edit-mosque view)
- [ ] Modify `MasjidCard.jsx` (conditional edit button)
- [ ] Update `Dashboard.jsx` (conditional sidebar)
- [ ] Add permission checks in components
- [ ] Test all role scenarios

### Testing Matrix
| Role | Can View | Can Edit | Sidebar |
|------|----------|----------|---------|
| system_admin | All mosques | All mosques | None (admin panel) |
| organization_admin | Org's mosques | Org's mosques | Organization |
| mosque_admin | Own mosque only | Own mosque only | Mosque |

---

## 🚫 Out of Scope (Don't Implement)
- ❌ User management/creation
- ❌ Login/logout redesign
- ❌ Multi-mosque admin (one admin, multiple mosques)
- ❌ Organization creation/deletion
- ❌ Advanced conflict resolution
- ❌ Audit logging (nice-to-have later)

---

## 📝 Next Steps

1. **Backend First**: Create `mosque_details.php` with auth
2. **Test Backend**: Use Postman/curl to verify auth rules
3. **Frontend Components**: Build `MosqueEditForm`
4. **Integration**: Wire up navigation and data flow
5. **Testing**: Verify each role behaves correctly
6. **Edge Cases**: Handle independent mosques, no-mosque users, etc.

---

## 🔍 Key Security Considerations

1. **Always verify on backend** - Never trust frontend role checks
2. **Check both role AND ownership** - Role isn't enough
3. **Return 403, not 404** - Be explicit about access denial
4. **Session validation** - Check session on every request
5. **SQL injection prevention** - Use parameterized queries
6. **XSS prevention** - Sanitize inputs on save

---

This plan ensures:
✅ Least-privilege access
✅ Role-based UI differences
✅ Secure authorization on every request
✅ Clear separation of concerns
✅ Edge case handling
✅ No scope creep
