// src/context/AuthContext.jsx
// Global Authentication Context using JWT

import { createContext, useState, useEffect, useContext } from 'react';
import { 
  getAccessToken, 
  getStoredUser, 
  clearAuthData, 
  isAuthenticated,
  getTokenExpiry 
} from '../utils/auth';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check authentication status on mount
  useEffect(() => {
    checkAuth();
  }, []);

  // Set up automatic token refresh before expiration
  useEffect(() => {
    if (!user) return;

    const timeUntilExpiry = getTokenExpiry();
    
    // Refresh 5 minutes before expiration
    const refreshTime = timeUntilExpiry - (5 * 60 * 1000);
    
    if (refreshTime > 0) {
      const timer = setTimeout(() => {
        refreshAccessToken();
      }, refreshTime);

      return () => clearTimeout(timer);
    }
  }, [user]);

  const checkAuth = async () => {
    try {
      const token = getAccessToken();
      
      if (!token || !isAuthenticated()) {
        setUser(null);
        setLoading(false);
        return;
      }

      // Verify token with backend
      const res = await fetch('http://localhost/api/jwt_auth.php', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      const data = await res.json();

      if (data.authenticated) {
        setUser(data.user);
      } else {
        clearAuthData();
        setUser(null);
      }
    } catch (error) {
      console.error('Auth check error:', error);
      clearAuthData();
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const refreshAccessToken = async () => {
    try {
      const refreshToken = localStorage.getItem('refresh_token');
      
      if (!refreshToken) {
        throw new Error('No refresh token');
      }

      const res = await fetch('http://localhost/api/jwt_refresh.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: refreshToken }),
      });

      const data = await res.json();

      if (data.success) {
        // Update access token
        localStorage.setItem('access_token', data.access_token);
      } else {
        throw new Error('Token refresh failed');
      }
    } catch (error) {
      console.error('Token refresh error:', error);
      logout();
    }
  };

  const login = (userData) => {
    setUser(userData);
  };

  const logout = async () => {
    try {
      const token = getAccessToken();
      
      if (token) {
        // Call logout endpoint (optional, for logging purposes)
        await fetch('http://localhost/api/jwt_logout.php', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      clearAuthData();
      setUser(null);
    }
  };

  const value = {
    user,
    loading,
    login,
    logout,
    checkAuth,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
