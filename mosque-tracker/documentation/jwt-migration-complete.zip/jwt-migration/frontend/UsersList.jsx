// src/components/UsersList.jsx
// Example component showing how to make authenticated API calls with JWT

import { useState, useEffect } from 'react';
import api from '../utils/axiosConfig';
// OR without axios:
// import { getAccessToken } from '../utils/auth';

export default function UsersList() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  // METHOD 1: Using configured axios instance (RECOMMENDED)
  const fetchUsers = async () => {
    try {
      setLoading(true);
      // Token is automatically added by axios interceptor
      const response = await api.get('/jwt_users.php');
      setUsers(response.data);
    } catch (err) {
      console.error('Error fetching users:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // METHOD 2: Using fetch with manual token management
  const fetchUsersWithFetch = async () => {
    try {
      setLoading(true);
      const token = getAccessToken();
      
      const response = await fetch('http://localhost/api/jwt_users.php', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }

      const data = await response.json();
      setUsers(data);
    } catch (err) {
      console.error('Error fetching users:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading users...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="users-list">
      <h2>Users</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Organization ID</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.user_name}</td>
              <td>{user.user_email}</td>
              <td>{user.role}</td>
              <td>{user.organization_id}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
