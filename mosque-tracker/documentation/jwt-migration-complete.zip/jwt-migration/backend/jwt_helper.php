<?php
require_once 'jwt_config.php';

/**
 * JWT Helper Class
 * Handles encoding, decoding, and validation of JWT tokens
 */
class JWTHelper {
    
    /**
     * Create a JWT access token
     * 
     * @param array $payload User data to encode
     * @return string JWT token
     */
    public static function createAccessToken($payload) {
        $header = [
            'typ' => 'JWT',
            'alg' => JWT_ALGORITHM
        ];

        $now = time();
        $tokenPayload = array_merge($payload, [
            'iat' => $now,                                    // Issued at
            'exp' => $now + JWT_ACCESS_TOKEN_LIFETIME,       // Expiration
            'iss' => JWT_ISSUER,                             // Issuer
            'type' => 'access'
        ]);

        return self::encode($header, $tokenPayload);
    }

    /**
     * Create a JWT refresh token
     * 
     * @param int $userId User ID
     * @return string JWT refresh token
     */
    public static function createRefreshToken($userId) {
        $header = [
            'typ' => 'JWT',
            'alg' => JWT_ALGORITHM
        ];

        $now = time();
        $tokenPayload = [
            'user_id' => $userId,
            'iat' => $now,
            'exp' => $now + JWT_REFRESH_TOKEN_LIFETIME,
            'iss' => JWT_ISSUER,
            'type' => 'refresh'
        ];

        return self::encode($header, $tokenPayload);
    }

    /**
     * Decode and validate a JWT token
     * 
     * @param string $token JWT token
     * @param string $expectedType 'access' or 'refresh'
     * @return object|false Decoded payload or false on failure
     */
    public static function validateToken($token, $expectedType = 'access') {
        try {
            $parts = explode('.', $token);
            
            if (count($parts) !== 3) {
                return false;
            }

            list($headerEncoded, $payloadEncoded, $signatureEncoded) = $parts;

            // Verify signature
            $signature = self::base64UrlDecode($signatureEncoded);
            $expectedSignature = hash_hmac('sha256', "$headerEncoded.$payloadEncoded", JWT_SECRET, true);

            if (!hash_equals($expectedSignature, $signature)) {
                return false;
            }

            // Decode payload
            $payload = json_decode(self::base64UrlDecode($payloadEncoded));

            if (!$payload) {
                return false;
            }

            // Validate expiration
            if (!isset($payload->exp) || $payload->exp < time()) {
                return false;
            }

            // Validate issuer
            if (!isset($payload->iss) || $payload->iss !== JWT_ISSUER) {
                return false;
            }

            // Validate token type
            if (!isset($payload->type) || $payload->type !== $expectedType) {
                return false;
            }

            return $payload;

        } catch (Exception $e) {
            error_log("JWT validation error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Encode JWT token
     * 
     * @param array $header Header data
     * @param array $payload Payload data
     * @return string JWT token
     */
    private static function encode($header, $payload) {
        $headerEncoded = self::base64UrlEncode(json_encode($header));
        $payloadEncoded = self::base64UrlEncode(json_encode($payload));
        
        $signature = hash_hmac('sha256', "$headerEncoded.$payloadEncoded", JWT_SECRET, true);
        $signatureEncoded = self::base64UrlEncode($signature);

        return "$headerEncoded.$payloadEncoded.$signatureEncoded";
    }

    /**
     * Base64 URL encode
     */
    private static function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Base64 URL decode
     */
    private static function base64UrlDecode($data) {
        return base64_decode(strtr($data, '-_', '+/'));
    }

    /**
     * Extract token from Authorization header
     * 
     * @return string|null Token or null if not found
     */
    public static function getTokenFromHeader() {
        $headers = getallheaders();
        
        if (!isset($headers['Authorization'])) {
            return null;
        }

        $authHeader = $headers['Authorization'];
        
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return $matches[1];
        }

        return null;
    }
}
?>
