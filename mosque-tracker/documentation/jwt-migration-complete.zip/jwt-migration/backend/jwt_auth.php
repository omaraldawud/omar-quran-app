<?php
/**
 * JWT-Based Auth Check Endpoint
 * Replaces session-based auth.php
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require 'db.php';
require 'jwt_helper.php';

try {
    // Extract token from Authorization header
    $token = JWTHelper::getTokenFromHeader();

    if (!$token) {
        echo json_encode(['authenticated' => false, 'message' => 'No token provided']);
        exit;
    }

    // Validate token
    $payload = JWTHelper::validateToken($token, 'access');

    if (!$payload) {
        http_response_code(401);
        echo json_encode(['authenticated' => false, 'message' => 'Invalid or expired token']);
        exit;
    }

    // Fetch fresh user data from database
    $stmt = $pdo->prepare("
        SELECT 
            id,
            organization_id,
            associated_mosque_id,
            user_name,
            user_email,
            role,
            is_active,
            user_profile_picture
        FROM users 
        WHERE id = ? AND is_active = 1
    ");
    $stmt->execute([$payload->user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // User not found or inactive
        http_response_code(401);
        echo json_encode(['authenticated' => false, 'message' => 'User not found or inactive']);
        exit;
    }

    // Return user data
    echo json_encode([
        'authenticated' => true,
        'user' => [
            'id'                   => $user['id'],
            'user_name'            => $user['user_name'],
            'user_email'           => $user['user_email'],
            'role'                 => $user['role'],
            'organization_id'      => $user['organization_id'],
            'associated_mosque_id' => $user['associated_mosque_id'],
            'user_profile_picture' => $user['user_profile_picture'],
        ]
    ]);

} catch (PDOException $e) {
    error_log("JWT Auth check error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'authenticated' => false,
        'error' => 'An error occurred'
    ]);
}
?>
