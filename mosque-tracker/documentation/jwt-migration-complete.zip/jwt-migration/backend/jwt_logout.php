<?php
/**
 * JWT-Based Logout Endpoint
 * 
 * Note: JWT tokens are stateless, so server-side logout isn't strictly necessary.
 * The client should simply delete the tokens from localStorage.
 * 
 * However, this endpoint exists for:
 * 1. Consistency with the session-based flow
 * 2. Future token blacklisting implementation (optional)
 * 3. Logging logout events
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require 'jwt_helper.php';

try {
    // Optionally validate the token to get user info for logging
    $token = JWTHelper::getTokenFromHeader();
    
    if ($token) {
        $payload = JWTHelper::validateToken($token, 'access');
        
        if ($payload) {
            // Log the logout event (optional)
            error_log("User {$payload->user_id} logged out at " . date('Y-m-d H:i:s'));
            
            // Future enhancement: Add token to blacklist table
            // This would require a database table to store invalidated tokens
            // until their expiration time
        }
    }

    // JWT logout is handled client-side by deleting tokens
    // This endpoint just confirms the action
    echo json_encode([
        'success' => true,
        'message' => 'Logged out successfully'
    ]);

} catch (Exception $e) {
    error_log("Logout error: " . $e->getMessage());
    // Even if there's an error, confirm logout succeeded
    // since client will delete tokens anyway
    echo json_encode([
        'success' => true,
        'message' => 'Logged out successfully'
    ]);
}
?>
