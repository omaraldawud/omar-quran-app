<?php
/**
 * JWT Configuration
 * 
 * SECURITY CRITICAL: Store JWT_SECRET in environment variable in production
 * Never commit the actual secret to version control
 */

// In production, use: getenv('JWT_SECRET')
// For development, you can use this constant (but change it!)
define('JWT_SECRET', 'YOUR_SUPER_SECRET_KEY_CHANGE_THIS_IN_PRODUCTION_' . hash('sha256', 'masjid_saas_secret'));

// Token expiration times (in seconds)
define('JWT_ACCESS_TOKEN_LIFETIME', 3600);        // 1 hour
define('JWT_REFRESH_TOKEN_LIFETIME', 604800);     // 7 days

// Token issuer
define('JWT_ISSUER', 'masjid_saas_api');

// Algorithm
define('JWT_ALGORITHM', 'HS256');

/**
 * Generate a secure secret key for production
 * Run this once and store the output in your environment variable
 * 
 * Usage: php jwt_config.php
 */
if (php_sapi_name() === 'cli' && basename(__FILE__) === basename($_SERVER['PHP_SELF'])) {
    echo "Generated JWT Secret (save this in your .env file):\n";
    echo bin2hex(random_bytes(32)) . "\n";
}
?>
