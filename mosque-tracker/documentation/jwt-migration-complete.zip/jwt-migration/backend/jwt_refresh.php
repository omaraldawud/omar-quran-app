<?php
/**
 * JWT Token Refresh Endpoint
 * Allows clients to get a new access token using a refresh token
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require 'db.php';
require 'jwt_helper.php';

// Parse JSON payload
$data = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    // Get refresh token from request body
    if (empty($data['refresh_token'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Refresh token is required']);
        exit;
    }

    $refreshToken = $data['refresh_token'];

    // Validate refresh token
    $payload = JWTHelper::validateToken($refreshToken, 'refresh');

    if (!$payload) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired refresh token']);
        exit;
    }

    // Fetch current user data
    $stmt = $pdo->prepare("
        SELECT 
            id, 
            organization_id, 
            associated_mosque_id,
            role, 
            user_name, 
            user_email,
            is_active,
            user_profile_picture
        FROM users 
        WHERE id = ? AND is_active = 1
    ");
    $stmt->execute([$payload->user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'User not found or inactive']);
        exit;
    }

    // Create new access token with fresh user data
    $tokenPayload = [
        'user_id'              => $user['id'],
        'user_name'            => $user['user_name'],
        'user_email'           => $user['user_email'],
        'role'                 => $user['role'],
        'organization_id'      => $user['organization_id'],
        'associated_mosque_id' => $user['associated_mosque_id'],
    ];

    $newAccessToken = JWTHelper::createAccessToken($tokenPayload);

    echo json_encode([
        'success' => true,
        'access_token' => $newAccessToken,
        'expires_in' => JWT_ACCESS_TOKEN_LIFETIME
    ]);

} catch (PDOException $e) {
    error_log("Token refresh error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'An internal error occurred'
    ]);
}
?>
