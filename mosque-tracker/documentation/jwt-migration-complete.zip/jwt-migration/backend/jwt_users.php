<?php
/**
 * JWT-Protected Users Endpoint
 * Example of how to protect API endpoints with JWT authentication
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require 'db.php';
require 'jwt_helper.php';

try {
    // STEP 1: Validate JWT token
    $token = JWTHelper::getTokenFromHeader();

    if (!$token) {
        http_response_code(401);
        echo json_encode(['error' => 'No authorization token provided']);
        exit;
    }

    $payload = JWTHelper::validateToken($token, 'access');

    if (!$payload) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid or expired token']);
        exit;
    }

    // STEP 2: Optional - Check user permissions
    // You can access user info from the token payload
    $currentUserId = $payload->user_id;
    $currentUserRole = $payload->role;

    // Example: Only admins can access this endpoint
    // if ($currentUserRole !== 'admin') {
    //     http_response_code(403);
    //     echo json_encode(['error' => 'Insufficient permissions']);
    //     exit;
    // }

    // STEP 3: Process the actual request
    $stmt = $pdo->query("
        SELECT id, user_name, user_email, user_phone, role, organization_id, associated_mosque_id
        FROM users
        ORDER BY user_name
    ");

    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($users);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
