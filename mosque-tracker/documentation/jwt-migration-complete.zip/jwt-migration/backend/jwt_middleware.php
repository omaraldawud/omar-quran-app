<?php
/**
 * JWT Authentication Middleware
 * Reusable function to protect any endpoint
 */

require_once 'jwt_helper.php';

/**
 * Protect an endpoint with JWT authentication
 * 
 * @param array $options Configuration options
 *   - 'allowed_roles': Array of roles allowed to access (optional)
 *   - 'require_active': Check if user is active in DB (default: false)
 * 
 * @return object|null Returns decoded token payload or terminates with 401/403
 */
function requireJWTAuth($options = []) {
    global $pdo;
    
    // Extract token
    $token = JWTHelper::getTokenFromHeader();

    if (!$token) {
        http_response_code(401);
        echo json_encode(['error' => 'No authorization token provided']);
        exit;
    }

    // Validate token
    $payload = JWTHelper::validateToken($token, 'access');

    if (!$payload) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid or expired token']);
        exit;
    }

    // Check if we need to verify user is still active in DB
    if (isset($options['require_active']) && $options['require_active']) {
        try {
            $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
            $stmt->execute([$payload->user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user || !$user['is_active']) {
                http_response_code(401);
                echo json_encode(['error' => 'User account is inactive']);
                exit;
            }
        } catch (PDOException $e) {
            error_log("DB error in JWT middleware: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Authentication error']);
            exit;
        }
    }

    // Check role-based access
    if (isset($options['allowed_roles']) && !empty($options['allowed_roles'])) {
        if (!in_array($payload->role, $options['allowed_roles'])) {
            http_response_code(403);
            echo json_encode(['error' => 'Insufficient permissions']);
            exit;
        }
    }

    // All checks passed - return the payload
    return $payload;
}

/**
 * Example usage in an endpoint:
 * 
 * <?php
 * require 'db.php';
 * require 'jwt_middleware.php';
 * 
 * // Protect endpoint - any authenticated user
 * $auth = requireJWTAuth();
 * 
 * // OR protect with role check
 * $auth = requireJWTAuth(['allowed_roles' => ['admin', 'super_admin']]);
 * 
 * // OR verify user is still active in DB
 * $auth = requireJWTAuth(['require_active' => true]);
 * 
 * // Access user info from token
 * $userId = $auth->user_id;
 * $userRole = $auth->role;
 * 
 * // Your endpoint logic here...
 * ?>
 */
?>
